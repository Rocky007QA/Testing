package stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utility.Reuse;

public class StepDefs {
	
	Reuse re=new Reuse();
	@Given("^I want to launch \"([^\"]*)\"$")
	public void i_want_to_launch(String arg1) throws Throwable {
	    re.selectDriver(arg1);
	}

	@When("^I search flight from \"([^\"]*)\" To \"([^\"]*)\"$")
	public void i_search_flight_from_To(String arg1, String arg2) throws Throwable {	
		    Thread.sleep(5000);
		    Actions act=new Actions(re.driver);
		    re.selcetElement("//input[@id='FromTag']").sendKeys(arg1);
		    Thread.sleep(3000);
	    String a=null;
	    List<Integer> z=new ArrayList<Integer>();
	    int x=0;
	    Thread.sleep(3000);
	    
	    act.moveToElement(re.driver.findElement(By.xpath("//a[contains(text(),'Hyderabad, IN - Rajiv Gandhi International (HYD)')]"))).click().build().perform();
	    re.selcetElement("//input[@id='ToTag']").sendKeys(arg2);
//	    driver.findElement(By.xpath()).sendKeys(arg2);
	    Thread.sleep(5000);
	    act.moveToElement(re.driver.findElement(By.xpath("//a[contains(text(),'New Delhi, IN - Indira Gandhi Airport (DEL)')]"))).click().build().perform();
//	    driver.findElement(By.xpath()).click();
	    re.selcetElement("//div[@class='monthBlock last']//tr[3]/td[4]").click();
	    Thread.sleep(5000);
	    re.selcetElement("//input[@id='SearchBtn']").click();
//	    driver.findElement(By.xpath()).click();
	    Thread.sleep(15000);
//	    List<WebElement> priceDetails=re.driver.findElements(By.xpath("//div[@data-ct-handle='solutionPrice']/p"));
//	    for(int i=0;i<priceDetails.size();i++) {
//	    	a=priceDetails.get(i).getText().replaceAll("₹", "").replaceAll(",", "");
//	    	x=Integer.parseInt(a);
//	    	z.add(x);
//	    }
//	    for(int k=0;k<z.size();k++)
//	    {
//	    	for(int l=1;l<z.size();l++) {
//	    		if(z.get(k)<=z.get(l))
//	    		{//	    			
//	    			
//	    		}
//	    	}
//	    	z.add(k+1,z.get(k));
//	    	System.out.println("flight select  "+z.get(k));
//	    }
//	}
//	    int minValue=z.get(0);
//	    for(int i=1;i<z.size();i++){ 
//	      if(z.get(i) < minValue){ 
//	        minValue = z.get(i);
//	      } 	      
//	    } 
//	    System.out.println(minValue);
	}
	
	@Given("^I select non stop flight$")
	public void i_select_non_stop_flight() throws Throwable {
		Thread.sleep(3000);
		if(re.driver.findElements(By.xpath("//label[contains(text(),'0 stop')]")).size()>0)
		{
			re.selcetElement("//label[contains(text(),'0 stop')]").click();
			
		}else if(re.driver.findElements(By.xpath("//p[contains(text(),'Non-stop')]")).size()>0){
			re.selcetElement("//p[contains(text(),'Non-stop')]").click();
		}
//		driver.findElement(By.xpath("/")).click();
		Thread.sleep(3000);
		
	}

//	@Then("^I choose lowest fair flight also fastest$")
//	public void i_choose_lowest_fair_flight_also_fastest() throws Throwable {
//		re.selectDriver("").click();
////	    driver.findElement(By.xpath("//*[@id=\"root\"]/div/main/div/div/div[2]/div[2]/div[8]/div[1]/div[1]/div[2]/div[4]/button")).click();
//	    Thread.sleep(5000);
//	}
//	
	@Given("^I select evening flights$")
	public void i_select_evening_flights() throws Throwable {
		Thread.sleep(3000);
//		re.selcetElement("//p[contains(text(),'Evening')]").click();
//		driver.findElement(By.xpath("//*[@id=\"root\"]/div/main/div/div/div[1]/div/aside/div[4]/div[3]/div[2]/div/label[4]/div[1]/span")).click();
		if(re.driver.findElements(By.xpath("//label[contains(text(),'Evening')]")).size()>0)
		{
			re.selcetElement("//label[contains(text(),'Evening')]").click();
			
		}else if(re.driver.findElements(By.xpath("//p[contains(text(),'Evening')]")).size()>0){
			re.selcetElement("//p[contains(text(),'Evening')]").click();
		}
		
		Thread.sleep(3000);
	}

	@Then("^I am able to choose lowest fair which also fastest flight$")
	public void i_am_able_to_choose_lowest_fair_which_also_fastest_flight() throws Throwable {
//		re.selcetElement("//button[contains(text(),'Book')][1]").click();
		if(re.driver.findElement(By.xpath("//*[@id=\"root\"]/div/main/div/div/div[2]/div[2]/div[8]/div[2]/div[1]/div[2]/div[4]/button")).isDisplayed()) {
			re.driver.findElement(By.xpath("//*[@id=\"root\"]/div/main/div/div/div[2]/div[2]/div[8]/div[2]/div[1]/div[2]/div[4]/button")).click();
		}else {
			re.driver.findElement(By.xpath("//*[@id=\"flightForm\"]/section[2]/div[4]/div/nav/ul/li[2]/table/tbody[2]/tr[2]/td[3]/button")).click();
		}
		
	    Thread.sleep(5000);
	}

	
}
