package utility;

import java.sql.Driver;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Reuse {
	public static WebDriver driver;
	public static void selectDriver(String driverName) {
		if(driverName.equalsIgnoreCase("Chrome")) {
	    	System.setProperty("webdriver.chrome.driver", "C:\\FlightReservationTesting\\chromedriver.exe");
	    	driver=new ChromeDriver();
	    	driver.manage().window().maximize();
	    	driver.get("https://www.cleartrip.com/");
	    }else if(driverName.equalsIgnoreCase("Safari")) {
	    	driver = new SafariDriver(); 
	    	driver.manage().window().maximize();
	    	driver.get("https://www.cleartrip.com/");
	    }
	}
	public static WebElement selcetElement(String e) {
		WebElement element=null;
		try {
			element=driver.findElement(By.xpath(e) );
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return element;
	}
	public static List<WebElement> sttoreElements(By e)
	{
		List<WebElement> element=null;
		try {
			element=driver.findElements(e);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return element;
	}
	
}
